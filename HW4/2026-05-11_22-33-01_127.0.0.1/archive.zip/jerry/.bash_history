./B <B.in
g++ -o D D.cpp
./D <D.in
g++ -o D D.cpp
./D <D.in
g++ -o D D.cpp
./D <D.in
g++ -o D D.cpp
./D <D.in
g++ -o D D.cpp
./D <D.in
g++ -o E E.cpp
./E <E.in
g++ -o E E.cpp
./E <E.in
g++ -o E E.cpp
./E <E.in
g++ -o E E.cpp
./E <E.in
g++ -o E E.cpp
./E <E.in
g++ -o E E.cpp
./E <E.in
g++ -o F F.cpp
./F <F.in
g++ -o F F.cpp
./F <F.in
g++ -o F F.cpp
./F <F.in
g++ -o F F.cpp
./F <F.in
g++ -o F F.cpp
./F <F.in
g++ -o F F.cpp
./F <F.in
g++ -o F F.cpp
./F <F.in
g++ -o F F.cpp
./F <F.in
g++ -o F F.cpp
./F <F.in
g++ -o F F.cpp
./F <F.in
g++ -o F F.cpp
./F <F.in
g++ -o F F.cpp
./F <F.in
g++ -o F F.cpp
./F <F.in
g++ -o F F.cpp
./F <F.in
g++ -o F F.cpp
./F <F.in
g++ -o F F.cpp
./F <F.in
g++ -o F F.cpp
./F <F.in
g++ -o F F.cpp
./F <F.in
g++ -o F F.cpp
./F <F.in
g++ -o F F.cpp
./F <F.in
dir
dir
cd compProg
dir
dir SBU
dir
dir
cd SBUd
cd SBU
dir
cd Spring26
dir
mkdir Ind7
code Ind7
python3 B.py <input.txt
g++ -o C C.cpp
./C <input.txt
g++ -o C C.cpp
./C <input.txt
g++ -o C C.cpp
./C <input.txt
g++ -o C C.cpp
./C <input.txt
g++ -o C C.cpp
./C <input.txt
g++ -o C C.cpp
./C <input.txt
g++ -o C C.cpp
./C <input.txt
g++ -o C C.cpp
./C <input.txt
g++ -o D D.cpp
./D <D.in
./D <input.txt
g++ -o E E.cpp
./E <input.txt
g++ -o E E.cpp
./E <input.txt
g++ -o E E.cpp
./E <input.txt
g++ -o E E.cpp
./E <input.txt
g++ -o E E.cpp
./E <input.txt
g++ -o E E.cpp
./E <input.txt
g++ -o E E.cpp
./E <input.txt
g++ -o E E.cpp
./E <input.txt
g++ -o E E.cpp
./E <input.txt
g++ -o E E.cpp
./E <input.txt
g++ -o E E.cpp
./E <input.txt
g++ -o E E.cpp
./E <input.txt
g++ -o F F.cpp
./F <F.in
./F <input.txt
g++ -o F F.cpp
./F <F.in
./F <input.txt
./F <F.in
g++ -o F F.cpp
./F <input.txt
g++ -o F F.cpp
./F <input.txt
g++ -o F F.cpp
./F <input.txt
g++ -o F F.cpp
./F <input.txt
g++ -o F F.cpp
./F <input.txt
g++ -o F F.cpp
./F <input.txt
g++ -o F F.cpp
./F <input.txt
g++ -o F F.cpp
./F <input.txt
g++ -o G G>cpp
g++ -o G G.cpp
./G <input.txt
g++ -o G G.cpp
./G <input.txt
g++ -o G G.cpp
./G <input.txt
g++ -o G G.cpp
./G <input.txt
g++ -o G G.cpp
./G <input.txt
g++ -o G G.cpp
./G <input.txt
g++ -o G G.cpp
./G <input.txt
dir
dir
cd compProb
dir
cd compProg
dir
cd SBU
dir
cd Spring26
ir
dir
mkdir Ind8
code Ind8
git pull
git status
git pull
git fetch
git status
git add run.py
git commit -m "modified jerry branch"
git push
git status
cd ..
git status
dir
cd hftc-26-submission-sbu-bitblitzers
dir
git push
git pull
python A.py <input.txt
python C.py <input.txt
pyton E.py <input.txt
python E.py <input.txt
pyton E.py <input.txt
python E.py <input.txt
python F.py <input.txt
g++ -o F F.cpp
./F <input.txt
g++ -o F F.cpp
./F <input.txt
g++ -o G G.cpp
./G <G.in
./G <input.txt
./G <G.in
g++ -o G G.cpp
./G <input.txt
g++ -o G G.cpp
./G <input.txt
g++ -o G G.cpp
./G <input.txt
g++ -o G G.cpp
./G <input.txt
g++ -o G G.cpp
./G <input.txt
g++ -o G G.cpp
./G <input.txt
g++ -o G G.cpp
./G <input.txt
g++ -o I I.cpp
./I <input.txt
g++ -o I I.cpp
./I <input.txt
g++ -o I I.cpp
./I <input.txt
g++ -o I I.cpp
./I <input.txt
g++ -o I I.cpp
./I <input.txt
g++ -o I I.cpp
./I <input.txt
g++ -o I I.cpp
./I <input.txt
g++ -o I I.cpp
./I <input.txt
g++ -o I I.cpp
./I <input.txt
g++ -o I I.cpp
./I <input.txt
g++ -o I I.cpp
./I <input.txt
g++ -o I I.cpp
./I <input.txt
g++ -o I I.cpp
./I <input.txt
/usr/bin/python3
python A.py <input.txt
python B.py <input.txt
g++ -o C C.cpp
./C <C.in
./C <input.txt
./C <C.in
./C <input.txt
g++ -o C C.cpp
./C <input.txt
g++ -o C C.cpp
./C <input.txt
g++ -o C C.cpp
./C <input.txt
g++ -o C C.cpp
./C <input.txt
g++ -o C C.cpp
./C <input.txt
g++ -o C C.cpp
./C <input.txt
g++ -o D D.cpp
./D <input.txt
python E.py <input.txt
python F.py <input.txt
g++ -o G G.cpp
./G <input.txt
g++ -o G G.cpp
./G <input.txt
g++ -o G G.cpp
./G <input.txt
g++ -o G G.cpp
./G <input.txt
g++ -o G G.cpp
./G <input.txt
g++ -o G G.cpp
./G <input.txt
g++ -o G G.cpp
./G <input.txt
g++ -o G G.cpp
./G <input.txt
g++ -o G G.cpp
./G <input.txt
g++ -o G G.cpp
./G <input.txt
g++ -o G G.cpp
./G <input.txt
g++ -o G G.cpp
./G <input.txt
dir
cd compProg
dir
cd Competitions
dir
cd CALICO
dir
mkdir Spring26
code Spring26
dir
cd ..
dir
cd ..
dir
cd SBU
dir
cd Spring26
dir
mkdir Ind9
code Ind9
dir
git checkout -b jerry1
git add .
git commit -m "added my current work to jerry1 branch"
git push
git push origin jerry1
git branch -r
git branch
git fetch origin
git reset --hard origin/jerry
git status
git checkout main
git pull
git status
git add run.py
git commit -m "added tickers"
git push
git push origin jerry
dir
python run.py
LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libffi.so.7 python run.py
git status
git add run.py
git commit -m "lets try this modified one"
git push
python run.py
LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libffi.so.7 python run.py
git status
git add run.py
git commit -m "updated logic trying to fix"
git push
git push --set-upstream origin jerry1
git status
git add trader.py
git commit -m "added example trader.py for olb imbalance+mean_reversion"
git push
pip install datamodel
pip install jsonpickel
pip install jsonpickle
git status
git add datamodel.py
git commit -m "datamodel added"
git push
git fetch --all
git branch -r
dir
cd Competitions
dir
cd IMC_Prosperity
dir
echo "# IMC_Prosperity" >> README.md
git init
git add README.md
git commit -m "first commit"
git branch -M main
git remote add origin git@github.com:jerryxiao14/IMC_Prosperity.git
git push -u origin main
dir
git add. 
git add .
git commit -m "added round1 data"
git push
cd ..
dir
code IMC_Prosperity
dir
code Stevens_HFTC
dir
cd Stevens_HFTC
dir
cd 2026
dir
code hftc-26-submission-sbu-bitblitzers
g++ -o H H.cpp
./H <H.in
g++ -o H H.cpp
./H <H.in
g++ -o H H.cpp
./H <H.in
g++ -o H H.cpp
./H <H.in
g++ -o H H.cpp
./H <H.in
g++ -o H H.cpp
./H <H.in
g++ -o H H.cpp
./H <H.in
g++ -o H H.cpp
./H <H.in
g++ -o H H.cpp
./H <H.in
python B.py <input.txt
python C.py <input.txt
g++ -o D D.cpp
./D <input.txt
g++ -o D D.cpp
./D <input.txt
g++ -o D D.cpp
./D <input.txt
g++ -o D D.cpp
./D <input.txt
g++ -o D D.cpp
./D <input.txt
dir
cd compProg
dir
cd CodeForces
dir
cd Div2
dir
cd Regular
dir
mkdir 1094
code 1094
git status
git add token.txt
git commit -m "f it im adding a token"
git push
dir
cd CS
dir
cd 328
dir
cd CSE328
dir
cd hw3
dir
mkdir build
cd build
cmake -DMAKE_BUILD_TYPE=Release ..
make
cd ..
./build/hw3
git pull
export DISPLAY=127.0.0.1:0
./build/hw3
cd ..
dir
code hw3
git pull
cd build
dir cd make
dir
cd hw3
dir
cd build
dir
make
cd ..
./build/hw3
./build/hw3
dir
cd CS
dir
cd 328
dir
cd CSE328
dir
cd hw3
find . -name "CMakeLists.txt"
dir
g++ -o C Goron_City.cpp
./C <C.in
g++ -o C Goron_City.cpp
./C <C.in
g++ -o C Goron_City.cpp
./C <C.in
g++ -o C Goron_City.cpp
./C <C.in
g++ -o C Goron_City.cpp
./C <C.in
g++ -o C Goron_City.cpp
./C <C.in
g++ -o C Goron_City.cpp
./C <C.in
g++ -o C Goron_City.cpp
./C <C.in
dir
cd compProg
dir
cd Competitions
dir
cd CodeSprintLA
dir
mkdir Opn26
dir
rmdir Opn26
mkdir Open26
code Open26
